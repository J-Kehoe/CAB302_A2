/**
 * 
 */
package sMart;

import java.awt.*;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

/**
 * @author jkkeh
 *
 */
public class SmartGUI extends JFrame implements Runnable, ActionListener {
	
	private static final long serialVersionUID = -7031008862559936404L;
	public static final int WIDTH = 300;
	public static final int HEIGHT = 200;
	private JPanel pnlDisplay;
	private JPanel pnlTwo;
	private JPanel pnlThree;
	private JPanel pnlFour;
	private JPanel pnlBtn; 
	private JButton btnLoad;
	private JButton btnUnload;
	private JButton btnFind;
	private JButton btnSwitch;
	private JTextArea displayCapital;
	private Font displayFont = new Font("Arial",Font.BOLD,40);
	private Store superMart = new Store();
	public double storeCapital = superMart.getCapital();

	/**
	 * @param title
	 * @throws HeadlessException
	 */
	public SmartGUI(String title) throws HeadlessException {
		super(title);
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent evt) {
		// TODO Auto-generated method stub
		//Get event source
		Object src=evt.getSource();
		
		//Consider the alternatives - not all active at once.
		if (src==btnLoad) {
			storeCapital = storeCapital - 20;
			JButton btn = ((JButton) src);
			displayCapital.setText(Double.toString(storeCapital));
			repaint();
		}
	}
	
	private void createGUI() {
		
		//Set dimensions for frame
		setSize(WIDTH, HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout()); 
		
		//Setup panels using CreatePanel
		pnlDisplay = createPanel(Color.WHITE);
		pnlTwo = createPanel(Color.LIGHT_GRAY);
		pnlThree = createPanel(Color.LIGHT_GRAY);
		pnlFour = createPanel(Color.LIGHT_GRAY);
		pnlBtn = createPanel(Color.LIGHT_GRAY);
		
		btnLoad = createButton("Capital");
		btnUnload = createButton("Unload");
		btnFind = createButton("Find");
		btnSwitch = createButton("Switch");
		
		displayCapital = createTextArea(displayFont);
		
		pnlDisplay.setLayout(new BorderLayout());
		pnlDisplay.add(displayCapital);

		
		//Add panels to frame
		this.getContentPane().add(pnlDisplay,BorderLayout.CENTER);
		this.getContentPane().add(pnlTwo,BorderLayout.EAST);
		this.getContentPane().add(pnlThree,BorderLayout.WEST);
		this.getContentPane().add(pnlFour,BorderLayout.NORTH);
		layoutButtonPanel();
		this.getContentPane().add(pnlBtn, BorderLayout.SOUTH);
		
		
		repaint();
		
		this.setVisible(true);
	}
	
	private void layoutButtonPanel() {
		GridBagLayout layout = new GridBagLayout();
		pnlBtn.setLayout(layout);
		
		//add components to grid
		GridBagConstraints constraints = new GridBagConstraints();
		
		//Defaults
		constraints.fill = GridBagConstraints.NONE;
		constraints.anchor = GridBagConstraints.CENTER;
		constraints.weightx = 100;
		constraints.weighty = 100;
		
		addToPanel(pnlBtn, btnLoad, constraints, 0, 0, 2, 1);
		addToPanel(pnlBtn, btnUnload, constraints, 3, 0, 2, 1);
		addToPanel(pnlBtn, btnFind, constraints, 0, 2, 2, 1);
		addToPanel(pnlBtn, btnSwitch, constraints, 3, 2, 2, 1); 
	} 
	
	/**
	*
	* A convenience method to add a component to given grid bag
	* layout locations. Code due to Cay Horstmann
	*
	* @param c the component to add
	* @param constraints the grid bag constraints to use
	* @param x the x grid position
	* @param y the y grid position
	* @param w the grid width of the component
	* @param h the grid height of the component
	*/
	private void addToPanel(JPanel jp,Component c, GridBagConstraints
	constraints,int x, int y, int w, int h) {
		constraints.gridx = x;
		constraints.gridy = y;
		constraints.gridwidth = w;
		constraints.gridheight = h;
		jp.add(c, constraints);
	}
	
	
	private JTextArea createTextArea(Font f) {
		JTextArea tex = new JTextArea();
		tex.setEditable(false);
		tex.setLineWrap(true);
		tex.setFont(f);
		tex.setBorder(BorderFactory.createEtchedBorder());
		return tex;
	}
	
	private JPanel createPanel(Color c) {
		//Create a JPanel object and store it in a local var
		//set the background color to that passed in c
		//Return the JPanel object
		JPanel pan = new JPanel();
		pan.setBackground(c);
		return pan;
	}
	
	private JButton createButton(String str) {
		//Create a JButton object and store it in a local var
		//Set the button text to that passed in str
		//Add the frame as an actionListener
		//Return the JButton object
		JButton but = new JButton();
		but.setText(str);
		but.addActionListener(this);
		return but;
		
	} 


	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		createGUI();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame.setDefaultLookAndFeelDecorated(true);
		SwingUtilities.invokeLater(new SmartGUI("BorderLayout"));

	}

}
