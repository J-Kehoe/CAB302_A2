package sMart;

public interface Stock_Interface {
	
}
