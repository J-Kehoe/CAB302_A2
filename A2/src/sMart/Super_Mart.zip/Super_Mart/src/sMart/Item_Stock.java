package sMart;

import java.util.AbstractList;



public static class Item_Stock extends AbstractList<Item> {
	
	private final Item[] a;
	
	Item_Stock(Item[] array) {
		a = array;
	}
	
	public Item get(int index) {
		return a[index];
	}
	
	public Item set(int index, Item element) {
		Item oldValue = a[index];
		a[index] = element;
		return oldValue;
	}
	
	public int size() {
		return a.length;
	}
}
