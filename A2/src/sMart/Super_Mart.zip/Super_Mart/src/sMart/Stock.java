package sMart;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

public class Stock extends AbstractList<Item> {

	private final Item[] a;
	
	public Stock(Item[] array) {
		a = array;
	}

	@Override
	public Item get(int index) {
		return a[index];
	}
	
	public Item set(int index, Item element) {
		Item oldValue = a[index];
		a[index] = element;
		return oldValue;
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return a.length;
	}
	
	public static List<Item> asList(Item[] a) {
		List<Item> asList = null;
		for (int i = 0; i <= a.length - 1; i++) {
			asList.add(a[i]);
		}
		
		return asList;
	}
	
	public static Item[] asArray(List<Item> b) {
		
		Item[] a = new Item[b.size()];
		a = b.toArray(a);
		
		return a;
	}

}


