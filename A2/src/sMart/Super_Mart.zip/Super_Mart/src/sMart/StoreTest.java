package sMart;
import static org.junit.Assert.*;

public class StoreTest {

}
