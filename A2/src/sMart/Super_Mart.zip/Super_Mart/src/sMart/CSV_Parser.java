package sMart;

import java.io.IOException;
import java.io.Writer;
import java.util.List;

public class CSV_Parser {

	public CSV_Parser() {
		// TODO Auto-generated constructor stub
	}
	
	public void generateCSV(Stock input) {
		input.formatStockCSV();
		
		
	}
	
	public void readCSV() {
		
	}
	
	

}
