package sMart;

public class CSV_Properties {

}
