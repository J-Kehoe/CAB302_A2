package sMart;

import java.awt.Dimension;
import java.awt.GridBagLayout;

import javax.swing.JScrollPane;
import javax.swing.JTable;

public class InventoryTable extends JTable {
	
	JTable inventoryTable;
	
	public InventoryTable(Object[][] input) {
		setLayout(new GridBagLayout());
		
		String[] columnNames = {"Name", "Quantity", "Man. Cost", 
				"Sell Price", "Reorder Point", "Reorder Amount", "Temp."};
		
		Object[][] data = input;
		
		inventoryTable = new JTable(data, columnNames);
		inventoryTable.setPreferredScrollableViewportSize(new Dimension(100, 200));
		inventoryTable.setFillsViewportHeight(true);
		
		JScrollPane scrollPane = new JScrollPane(inventoryTable);
	}
}
